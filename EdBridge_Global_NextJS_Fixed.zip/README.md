# EdBridge Global Limited – Next.js Website

## Tech Stack
- Next.js 14 (App Router) · TypeScript · Tailwind CSS
- Prisma ORM + PostgreSQL (Vercel Postgres or Supabase)
- NextAuth.js v4 (Credentials + JWT)
- React Hook Form · React Hot Toast · Lucide React

---

## Quick Start

```bash
# 1. Install
npm install

# 2. Configure environment
cp .env.local.example .env.local
# Fill in DATABASE_URL and NEXTAUTH_SECRET

# 3. Set up database
npx prisma generate
npx prisma db push

# 4. Run
npm run dev
```

---

## Deploy to Vercel

1. Push to GitHub
2. Import repo in Vercel
3. Add Vercel Postgres from Storage tab → DATABASE_URL auto-added
4. Add NEXTAUTH_SECRET in Environment Variables
5. Deploy

---

## Key Routes

| Route | Description |
|---|---|
| / | Home |
| /about | About page |
| /founders | Founders with Book Consultation buttons |
| /services | All 10 services |
| /book-consultation | Booking form (pre-fills from founders page) |
| /blog | Blog listing |
| /testimonials | Testimonials |
| /contact | Contact form |
| /login | Sign in |
| /register | Register |
| /dashboard | Client dashboard |
| /admin | Admin dashboard |

---

## Customisation

- Founder bios & qualifications → `app/founders/page.tsx`
- Founder photos → `public/founders/helen.jpg` & `david.jpg`
- Contact details → `components/layout/Footer.tsx`
- Brand colours → `tailwind.config.js`
