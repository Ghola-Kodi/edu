import Link from "next/link";
import Image from "next/image";

const founders = [
  {
    name:  "Helen Njeri Kamau",
    title: "Co-Founder & CEO",
    slug:  "helen",
    image: "/founders/helen.jpg",
    fallback: "https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?w=600",
    bio:   "Helen is a seasoned education consultant with over 15 years of experience in international curriculum development, school leadership coaching, and student transition support. She holds a Master's in Education Leadership from the University of Nairobi and is a certified Cambridge International Education trainer. Helen has worked with over 120 schools across East Africa, helping them transition to world-class curricula and build high-performing teams.",
    qualifications: ["M.Ed – Education Leadership, University of Nairobi","Cambridge International Education Trainer","IB Curriculum Consultant","School Governance Specialist"],
    email: "helen@edbridgeglobal.com",
  },
  {
    name:  "David Ouma Achieng",
    title: "Co-Founder & Director of Operations",
    slug:  "david",
    image: "/founders/david.jpg",
    fallback: "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=600",
    bio:   "David brings expertise in university placement strategy, career counselling, and institutional partnerships across Africa and Europe. With a background in International Relations and Education Management, David has helped over 500 students secure placements in top universities across the UK, USA, Canada, and Australia. He leads EdBridge Global's partnerships with international institutions and scholarship bodies.",
    qualifications: ["B.A. – International Relations, University of Dar es Salaam","Postgraduate Diploma, Education Management","Certified Career Development Facilitator","UK University Placement Advisor (UCAS Qualified)"],
    email: "david@edbridgeglobal.com",
  },
];

export default function FoundersPage() {
  return (
    <div className="min-h-screen bg-soft-grey">
      <section className="bg-primary py-20 text-center">
        <div className="max-w-3xl mx-auto px-6">
          <span className="section-label">Leadership</span>
          <h1 className="text-4xl font-heading font-bold text-white mt-2">Meet Our Founders</h1>
          <div className="divider mx-auto mt-3"/>
          <p className="text-white/70 text-lg mt-4">Built by educators, for educators. Our founders bring decades of combined experience in international education and student guidance.</p>
        </div>
      </section>

      <section className="py-20 px-6">
        <div className="max-w-6xl mx-auto flex flex-col gap-16">
          {founders.map((founder, i) => (
            <div key={founder.slug} className={`bg-white rounded-2xl shadow-md overflow-hidden flex flex-col lg:flex-row ${i%2!==0?"lg:flex-row-reverse":""}`}>
              <div className="lg:w-[360px] shrink-0 relative min-h-[380px] bg-soft-grey">
                <Image
                  src={founder.fallback}
                  alt={`${founder.name} – ${founder.title}`}
                  fill
                  className="object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-primary/65 to-transparent"/>
                <div className="absolute bottom-5 left-5 right-5">
                  <p className="font-heading font-bold text-white text-xl">{founder.name}</p>
                  <p className="text-gold text-sm font-semibold">{founder.title}</p>
                </div>
              </div>
              <div className="flex-1 p-8 lg:p-12 flex flex-col justify-between">
                <div>
                  <h2 className="text-2xl font-heading font-bold text-primary">{founder.name}</h2>
                  <p className="text-gold font-semibold text-sm mt-1 mb-4">{founder.title}</p>
                  <div className="divider"/>
                  <p className="text-charcoal/80 leading-relaxed mt-4 mb-6">{founder.bio}</p>
                  <h4 className="font-heading font-bold text-primary text-xs uppercase tracking-widest mb-3">Qualifications & Expertise</h4>
                  <ul className="flex flex-col gap-2">
                    {founder.qualifications.map(q=>(
                      <li key={q} className="flex items-start gap-2 text-sm text-charcoal/70">
                        <span className="text-gold mt-0.5 shrink-0">✓</span>{q}
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="flex flex-wrap gap-3 mt-8 pt-6 border-t border-border">
                  <Link href={`/book-consultation?founder=${founder.slug}&name=${founder.name.split(" ")[0]}`} className="btn-primary">
                    📅 Book Consultation with {founder.name.split(" ")[0]}
                  </Link>
                  <a href={`mailto:${founder.email}`} className="btn-teal">✉ Email {founder.name.split(" ")[0]}</a>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
